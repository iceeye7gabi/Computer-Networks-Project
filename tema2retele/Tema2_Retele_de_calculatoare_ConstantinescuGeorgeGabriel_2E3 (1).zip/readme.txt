pt server: gcc server.c -lpthread -lsqlite3
pt client: gcc client.c
port:2323
